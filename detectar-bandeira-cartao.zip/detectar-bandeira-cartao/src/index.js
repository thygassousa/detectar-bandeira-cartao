const readline = require('readline');

function getCardBrand(cardNumber) {
    const cardPatterns = [
        { brand: "MasterCard", pattern: /^5[1-5][0-9]{14}$/ },
        { brand: "Visa", pattern: /^4[0-9]{12}(?:[0-9]{3})?$/ },
        { brand: "American Express", pattern: /^3[47][0-9]{13}$/ },
        { brand: "Diners Club", pattern: /^3(?:0[0-5]|[68][0-9])[0-9]{11}$/ },
        { brand: "Discover", pattern: /^6(?:011|5[0-9]{2})[0-9]{12}$/ },
        { brand: "EnRoute", pattern: /^(2014|2149)[0-9]{11}$/ },
        { brand: "JCB", pattern: /^(?:2131|1800|35\d{3})\d{11}$/ },
        { brand: "Voyager", pattern: /^8699[0-9]{11}$/ },
        { brand: "Hipercard", pattern: /^(606282|637095)[0-9]{10,12}$/ },
        { brand: "Aura", pattern: /^50[0-9]{14,17}$/ }
    ];

    cardNumber = cardNumber.replace(/\D/g, '');

    for (const { brand, pattern } of cardPatterns) {
        if (pattern.test(cardNumber)) {
            return brand;
        }
    }

    return "Bandeira desconhecida";
}

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function perguntar() {
    rl.question('Digite o número do cartão de crédito (ou "sair" para finalizar): ', (cardNumber) => {
        if (cardNumber.toLowerCase() === 'sair') {
            console.log('Encerrando o programa...');
            rl.close();
            return;
        }

        const brand = getCardBrand(cardNumber);
        console.log(`A bandeira do cartão é: ${brand}\n`);

        
        perguntar();
    });
}

perguntar();
